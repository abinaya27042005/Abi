year=int(input("Enter a year:"))
if(year % 4==0):
  print("Tha given year is leap year")
else:
  print("The given uear is not a leap year")